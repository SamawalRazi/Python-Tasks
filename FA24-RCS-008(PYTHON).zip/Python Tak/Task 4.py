import pandas as pd

data = {
    'C1': [1, 2, 3, 5, 5],
    'C2': [6, 7, 5, 4, 8],
    'C3': [7, 9, 8, 6, 5],
    'C4': [7, 5, 2, 8, 8]
}

df = pd.DataFrame(data)
# 4.1
first_two_rows = df.head(2)
print("First two rows:")
print(first_two_rows)

#4.2
second_column = df['C2']
print("\nSecond column:")
print(second_column)

# 4.3 
df.rename(columns={'C3': 'B3'}, inplace=True)

# 4.4 
df['Sum'] = df.sum(axis=1)

# 4.5 
print("\nDataframe after renaming column and adding 'Sum' column:")
print(df)

#4.6
import pandas as pd

df_csv = pd.read_csv('hello_sample.csv')

# 4.7 
print("Complete dataframe:")
print(df_csv)

# 4.8 
print("\nBottom 2 records:")
print(df_csv.tail(2))

# 4.9 
print("\nInformation about the dataframe:")
print(df_csv.info())

# 4.10 
print("\nShape of the dataframe (rows x columns):")
print(df_csv.shape)

# 4.11 
print("\nDataframe sorted by 'Weight':")
df_sorted = df_csv.sort_values(by='Weight')
print(df_sorted)

# 4.12 
print("\nCheck for missing values using isnull():")
print(df_csv.isnull())

print("\nDataframe after using dropna() to remove rows with missing values:")
df_no_na = df_csv.dropna()
print(df_no_na)

