# 2.1
import numpy as np

A = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]

A_array = np.array(A)

print(A_array)

#2.2
import numpy as np

A = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]])

b = A[:2, :2]

print(b)

# 2.3  
import numpy as np

A = np.array([[1, 2, 3, 4],
              [5, 6, 7, 8],
              [9, 10, 11, 12]])

C = np.empty(A.shape)

print(C)

# 2.4
import numpy as np

A = np.array([[1, 2, 3, 4],
              [5, 6, 7, 8],
              [9, 10, 11, 12]])

z = np.array([1, 0, 1])

C = np.empty(A.shape)

for i in range(A.shape[1]):  
    C[:, i] = A[:, i] + z  

print(C)


import numpy as np

X = np.array([[1, 2], [3, 4]])
Y = np.array([[5, 6], [7, 8]])

# 2.5
matrix_sum = X + Y
print("Sum of matrices X and Y:\n", matrix_sum)

# 2.6
matrix_product = np.dot(X, Y)
print("Matrix multiplication of X and Y:\n", matrix_product)

# 2.7
sqrt_Y = np.sqrt(Y)
print("Element-wise square root of Y:\n", sqrt_Y)

v = np.array([9, 10])

# 2.8
dot_product = np.dot(X, v)
print("Dot product of X and v:\n", dot_product)

# 2.9
column_sum = np.sum(X, axis=0)
print("Sum of each column of X:\n", column_sum)
