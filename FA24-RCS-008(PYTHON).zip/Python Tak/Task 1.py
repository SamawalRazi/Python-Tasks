nums = [3, 5, 7, 8, 12]

# 1.1
cubes = []

for num in nums:
    cubes.append(num ** 3)

print(cubes)
# 1.2

dict_data = {}

dict_data['parrot'] = 2
dict_data['goat'] = 4
dict_data['spider'] = 8
dict_data['crab'] = 10

print(dict_data)

# 1.3
dict_data = {
    'parrot': 2,
    'goat': 4,
    'spider': 8,
    'crab': 10
}

total_legs = 0

for animal, legs in dict_data.items():

    print(f'{animal}: {legs} legs')

    total_legs += legs 

print(f'Total number of legs: {total_legs}')

# 1.4
A = (3, 9, 4, [5, 6])

A[3][0] = 8

print(A)

# 1.5
A = (3, 9, 4, [5, 6])

A[3][0] = 8

del A

try:
    print(A)
except NameError as e:
    print(f'Error: {e}')

# 1.6
try:
    print(A)
except NameError as e:
    print(f'Error: {e}')

B = ('a', 'p', 'p', 'l', 'e')

count_p = B.count('p')

print(f"The number of occurrences of 'p' in the tuple is: {count_p}")

B = ('a', 'p', 'p', 'l', 'e')

# 1.7
index_l = B.index('l')

print(f"The index of 'l' in the tuple is: {index_l}")
