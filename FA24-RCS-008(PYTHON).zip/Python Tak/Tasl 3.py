# 3.1
def Compute(distance, time):

    if time == 0:
        return "Time cannot be zero."
    else:
        velocity = distance / time
        return velocity

distance = 500 
time = 10       
velocity = Compute(distance, time)

print(f"Velocity: {velocity} meters/second")

# 3.2

even_num = [2, 4, 6, 8, 10, 12]

def mult(even_num):
    product = 1 
    for num in even_num:
        product *= num  
    return product

product_result = mult(even_num)

print(f"Product of all even numbers: {product_result}")


    
